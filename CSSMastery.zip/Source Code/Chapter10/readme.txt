MORE THAN DOODLES CASE STUDY
Author: Simon Collison

Case Study for the CSS MASTERY BOOK by Andy Budd

Main files:

index.html (the main page)

gallery.html (the gallery page)

contact.html (the contact page)

book.css (main stylesheet)

cb.js (JavaScript for the rounded corners)

case_study.html (contains all of the source code used in the text of the case study).

CONTACT ME

Please address any questions to simon.collison@agenzia.co.uk