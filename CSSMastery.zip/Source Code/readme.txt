The code, images and designs for this book are released under a Creative Commons Attribution-NonCommercial-ShareAlike 2.5 License.

http://creativecommons.org/licenses/by-nc-sa/2.5/

You are free:

* to copy, distribute, display, and perform the work
* to make derivative works

Under the following conditions:

*Attribution. You must attribute the work in the manner specified by the author or licensor.

*Noncommercial. You may not use this work for commercial purposes.

*Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting work only under a license identical to this one.

*For any reuse or distribution, you must make clear to others the license terms of this work.

*Any of these conditions can be waived if you get permission from the copyright holder.

CONTACT ME

Please address any questions to info@andybudd.com.